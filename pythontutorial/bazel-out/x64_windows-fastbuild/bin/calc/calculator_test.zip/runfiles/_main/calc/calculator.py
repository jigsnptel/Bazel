class Calculator:
  def add(self, x, y): return x + y;